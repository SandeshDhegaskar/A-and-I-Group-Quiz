package com.miniProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MultipleQuestion {
	Connection connection=null;
	PreparedStatement pst=null;
	
	
	public void getMultipleQuestion() throws SQLException {
		int i=0;
		
		try {
		ConnectionMultipleQuestion cmq=new ConnectionMultipleQuestion();
		connection=cmq.getConnectionDetails();
		
		pst=connection.prepareStatement("insert into question (qus,ans) values (?,?)");
		
		pst.setString(1, "Total Number of Reserve keyword in java ?");
		pst.setString(2, "A");
		i = pst.executeUpdate();
		
		pst.setString(1, "Array in Java are-");
		pst.setString(2, "B");
		i = pst.executeUpdate();
		
		pst.setString(1, "In which of the following is toString() method defined?");
		pst.setString(2, "A");
		i = pst.executeUpdate();
		
		pst.setString(1, "compareTo() returns-");
		pst.setString(2, "B");
		i = pst.executeUpdate();
		
		pst.setString(1, "What is the size of int data type?");
		pst.setString(2, "C");
		i = pst.executeUpdate();
		
		pst.setString(1, "What is the implicit return type of constructor?");
		pst.setString(2, "C");
		i = pst.executeUpdate();
		
		pst.setString(1, "Where does the system stores parameters and local variables whenever a method is invoked?");
		pst.setString(2, "B");
		i = pst.executeUpdate();
		
		pst.setString(1, "If you want to searialize some field of class by using -");
		pst.setString(2, "A");
		i = pst.executeUpdate();
		
		pst.setString(1, "Which of the following is used to find and fix bugs in the program?");
		pst.setString(2, "D");
		i = pst.executeUpdate();
		
		pst.setString(1, "Identify the modifier which cannot be used for constructor.");
		pst.setString(2, "C");
		i = pst.executeUpdate();
		
		pst.setString(1, "Insertion order is preserved but in an Ascending manner?");
		pst.setString(2, "B");
		i = pst.executeUpdate();
	 
		
		
		System.out.println("Record is inserted successfully.." + i);
		
		pst.close();
		connection.close();
	}
	catch (Exception e) {
		e.printStackTrace();
	}
		
		finally
		{
		 connection.close();
		 pst.close();
		}
}
}
