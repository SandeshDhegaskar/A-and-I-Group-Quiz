package com.miniProject;

import java.sql.SQLException;
import java.util.Scanner;

public class MainCalling {
	
public void getDetails() throws SQLException {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your choice");
		System.out.println("1. Register/LogIn");
		System.out.println("2. Student Data");
		System.out.println("3. Your Result");
		
		int c= sc.nextInt();
		/**/
		switch(c) {
		case 1:
			Registration_LogIn rl= new Registration_LogIn();
			rl.StudentRegister();
		break;
		case 2:
			Result rs= new Result();
			rs.getStudentsData();
		break;
		case 3:
			Result rs1= new Result();
			rs1.getYourResult() ;
		break;
		default: System.out.println("Please choose valid option");
		}
		

	}

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
		//MultipleQuestion qa= new MultipleQuestion();
		//qa.getMultipleQuestion();
		
		//InserOptions io= new InserOptions();
		//io.insertOpt();
     	//MultipleQuestion  mc=new MultipleQuestion();
     	//mc.getMultipleQuestion();
		
		MainCalling call= new MainCalling();
		call.getDetails();
	 //InserOptions io=new InserOptions();
	//io.insertOpt();
	}
}