package com.miniProject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class InserOptions {
	Connection connection=null;
	PreparedStatement pst=null;
	
	
	public void insertOpt() throws SQLException
	{
		int i=0;
		try {
		ConnectionMultipleQuestion ct=new ConnectionMultipleQuestion();
		connection=ct.getConnectionDetails();
		
		
		pst=connection.prepareStatement("insert into Options(Option1,Option2,Option3,Option4)values(?,?,?,?)");
		
		
		pst.setString(1, "53");
		pst.setString(2, "56" );
		pst.setString(3, "54");
		pst.setString(4, "50" );
		i=pst.executeUpdate();
		
		pst.setString(1, "class");
		pst.setString(2, "object" );
		pst.setString(3, "access specifier");
		pst.setString(4, "constructor" );
		i=pst.executeUpdate();
		
		pst.setString(1, "object class");
		pst.setString(2, "collection" );
		pst.setString(3, "array");
		pst.setString(4, "Thread" );
		i=pst.executeUpdate();
		
		pst.setString(1, "String");
		pst.setString(2, "int value" );
		pst.setString(3, "double value");
		pst.setString(4, "float" );
		i=pst.executeUpdate();
		
		pst.setString(1, "16 byte");
		pst.setString(2, "32 byte" );
		pst.setString(3, "4 byte");
		pst.setString(4, "8 byte" );
		i=pst.executeUpdate();
		
		pst.setString(1, "void");
		pst.setString(2, "boolean" );
		pst.setString(3, "A Class object in which its defined");
		pst.setString(4, "none" );
		i=pst.executeUpdate();
		
		pst.setString(1, "Heap");
		pst.setString(2, "Stack Area" );
		pst.setString(3, "Constant Pool");
		pst.setString(4, "Class Area" );
		i=pst.executeUpdate();
		
		pst.setString(1, "Transient Keyword");
		pst.setString(2, "Final Keyword" );
		pst.setString(3, "Volatile Keyword");
		pst.setString(4, "Static KeyWord" );
		i=pst.executeUpdate();
		
		pst.setString(1, "JRE");
		pst.setString(2, "JVM" );
		pst.setString(3, "JIT");
		pst.setString(4, "JDB" );
		i=pst.executeUpdate();
		
		pst.setString(1, "Final");
		pst.setString(2, "Non-static" );
		pst.setString(3, "Static");
		pst.setString(4, "Private" );
		i=pst.executeUpdate();
		
		pst.setString(1, "HashMap");
		pst.setString(2, "TreeSet and TreeMap" );
		pst.setString(3, "HashSet");
		pst.setString(4, "ArrayList" );
		i=pst.executeUpdate();
	
		
		System.out.println("Record is inserted successfully ..." +i);
		
	}
		
	catch(Exception e)
		{
		e.printStackTrace();
	    }
		
	 finally 
	   {
		 connection.close();
		 pst.close();
	   }
		
	}
}
